from pathlib import Path

NAV_REQUEST_DIR = Path("/home/pc415-28/llm_package/bus/nav_request")
NAV_REQUEST_DONE_DIR = Path("/home/pc415-28/llm_package/bus/nav_request_done")

MAP_JSON_PATH = Path("/home/pc415-28/llm_package/knowledge/hospital_1f_map.json")

POLL_INTERVAL = 0.5
STABLE_WAIT = 0.2
SKIP_EXISTING_ON_START = True
