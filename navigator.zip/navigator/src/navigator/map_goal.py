import json
import math
from pathlib import Path


class MapGoalResolver:
    def __init__(self, map_json_path: Path):
        self.map_json_path = map_json_path
        self.map_data = self._load_map()

    def _load_map(self) -> dict:
        if not self.map_json_path.exists():
            raise FileNotFoundError(f"맵 JSON을 찾을 수 없습니다: {self.map_json_path}")
        return json.loads(self.map_json_path.read_text(encoding="utf-8"))

    def find_zone(self, place_name: str):
        for zone in self.map_data.get("zones", []):
            if str(zone.get("name", "")).strip() == place_name.strip():
                return zone
        return None

    def resolve_goal(self, place_name: str) -> dict:
        zone = self.find_zone(place_name)
        if zone is None:
            raise ValueError(f"맵에서 장소를 찾을 수 없습니다: {place_name}")

        x_min = float(zone["x_min"])
        x_max = float(zone["x_max"])
        y_min = float(zone["y_min"])
        y_max = float(zone["y_max"])
        yaw_deg = float(zone.get("rotation_deg", 0.0))

        goal_x = (x_min + x_max) / 2.0
        goal_y = (y_min + y_max) / 2.0
        goal_yaw_rad = math.radians(yaw_deg)

        return {
            "place_name": place_name,
            "x": goal_x,
            "y": goal_y,
            "yaw_rad": goal_yaw_rad,
            "yaw_deg": yaw_deg,
            "description": str(zone.get("description", "")).strip(),
        }
