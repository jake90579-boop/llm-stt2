import time
from pathlib import Path
from typing import Set

from navigator.file_utils import is_file_stable, read_json_file, move_file
from navigator.map_goal import MapGoalResolver
from navigator.nav_client import Nav2Client


class NavigatorWatcher:
    def __init__(
        self,
        input_dir,
        done_dir,
        resolver,
        nav_client,
        poll_interval=0.5,
        stable_wait=0.2,
        skip_existing_on_start=True,
    ):
        self.input_dir = input_dir
        self.done_dir = done_dir
        self.resolver = resolver
        self.nav_client = nav_client
        self.poll_interval = poll_interval
        self.stable_wait = stable_wait
        self.seen: Set[str] = set()

        if skip_existing_on_start:
            for path in self.input_dir.glob("*.json"):
                self.seen.add(path.name)

    def _print_block(self, filename, place_name, goal):
        print()
        print("=" * 60)
        print(f"[NAVIGATOR] 새 이동 요청: {filename}")
        print(f"[PLACE] {place_name}")
        print(f"[GOAL] x={goal['x']:.3f}, y={goal['y']:.3f}, yaw_deg={goal['yaw_deg']:.1f}")
        if goal["description"]:
            print(f"[DESCRIPTION] {goal['description']}")
        print("=" * 60)

    def process_file(self, file_path: Path):
        if not is_file_stable(file_path, self.stable_wait):
            return

        try:
            payload = read_json_file(file_path)
            place_name = str(payload.get("place_name", "")).strip()
            if not place_name:
                raise ValueError("place_name이 비어 있습니다.")

            goal = self.resolver.resolve_goal(place_name)
            self._print_block(file_path.name, place_name, goal)

            result = self.nav_client.go_to(
                goal["x"],
                goal["y"],
                goal["yaw_rad"],
            )
            print(f"[NAV RESULT] {result}")

            move_file(file_path, self.done_dir)

        except Exception as e:
            print()
            print("=" * 60)
            print(f"[ERROR] navigator 처리 실패: {file_path.name}")
            print(e)
            print("=" * 60)

    def run(self):
        while True:
            try:
                json_files = sorted(self.input_dir.glob("*.json"))

                for file_path in json_files:
                    if file_path.name in self.seen:
                        continue

                    self.seen.add(file_path.name)
                    self.process_file(file_path)

                time.sleep(self.poll_interval)

            except KeyboardInterrupt:
                break
            except Exception:
                time.sleep(self.poll_interval)
