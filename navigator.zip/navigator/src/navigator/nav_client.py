import math

import rclpy
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator


class Nav2Client:
    def __init__(self):
        rclpy.init(args=None)
        self.navigator = BasicNavigator()

    def wait_until_active(self):
        self.navigator.waitUntilNav2Active()

    def _build_pose(self, x: float, y: float, yaw_rad: float) -> PoseStamped:
        pose = PoseStamped()
        pose.header.frame_id = "map"
        pose.header.stamp = self.navigator.get_clock().now().to_msg()

        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.position.z = 0.0

        qz = math.sin(yaw_rad / 2.0)
        qw = math.cos(yaw_rad / 2.0)

        pose.pose.orientation.x = 0.0
        pose.pose.orientation.y = 0.0
        pose.pose.orientation.z = qz
        pose.pose.orientation.w = qw
        return pose

    def go_to(self, x: float, y: float, yaw_rad: float):
        goal_pose = self._build_pose(x, y, yaw_rad)
        self.navigator.goToPose(goal_pose)

        while not self.navigator.isTaskComplete():
            feedback = self.navigator.getFeedback()
            if feedback is not None:
                pass

        result = self.navigator.getResult()
        return result
