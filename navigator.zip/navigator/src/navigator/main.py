from navigator.config import (
    NAV_REQUEST_DIR,
    NAV_REQUEST_DONE_DIR,
    MAP_JSON_PATH,
    POLL_INTERVAL,
    STABLE_WAIT,
    SKIP_EXISTING_ON_START,
)
from navigator.file_utils import ensure_dir
from navigator.map_goal import MapGoalResolver
from navigator.nav_client import Nav2Client
from navigator.watcher import NavigatorWatcher


def main():
    ensure_dir(NAV_REQUEST_DIR)
    ensure_dir(NAV_REQUEST_DONE_DIR)

    print()
    print("=" * 60)
    print("[INFO] navigator 패키지 시작")
    print(f"[INFO] nav request 폴더: {NAV_REQUEST_DIR}")
    print(f"[INFO] map json: {MAP_JSON_PATH}")
    print("=" * 60)

    resolver = MapGoalResolver(MAP_JSON_PATH)
    nav_client = Nav2Client()
    nav_client.wait_until_active()

    watcher = NavigatorWatcher(
        input_dir=NAV_REQUEST_DIR,
        done_dir=NAV_REQUEST_DONE_DIR,
        resolver=resolver,
        nav_client=nav_client,
        poll_interval=POLL_INTERVAL,
        stable_wait=STABLE_WAIT,
        skip_existing_on_start=SKIP_EXISTING_ON_START,
    )
    watcher.run()


if __name__ == "__main__":
    main()
