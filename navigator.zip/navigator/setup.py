from setuptools import setup

package_name = "navigator"

setup(
    name=package_name,
    version="0.1.0",
    packages=[package_name],
    package_dir={"": "src"},
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/navigator"]),
        ("share/navigator", ["package.xml"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="pc415-28",
    maintainer_email="pc415-28@localhost",
    description="Navigator package for sending Nav2 goals from LLM outputs",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "navigator = navigator.main:main",
        ],
    },
)
