#!/bin/bash

cd /home/pc415-28/llm_package/navigator || exit 1

source /opt/ros/galactic/setup.bash || exit 1

colcon build --packages-select navigator || exit 1
source install/setup.bash || exit 1

ros2 run navigator navigator
